/**
 * Standard application error for expected API failures.
 *
 * Examples:
 * - Invalid input
 * - Unauthorized access
 * - Resource not found
 * - Forbidden actions
 */
export class AppError extends Error {
  constructor(message, statusCode = 500) {
    super(message);

    this.name = "AppError";
    this.statusCode = statusCode;
    this.isOperational = true;

    Error.captureStackTrace?.(this, this.constructor);
  }
}
